Overlay files for the official sherpa-onnx Android sample.
These files are copied into android/SherpaOnnx/app/src/main/ by the included GitHub Actions workflow.
