package com.k2fsa.sherpa.onnx

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var recognizer: OnlineRecognizer
    private lateinit var startButton: Button
    private lateinit var clearButton: Button
    private lateinit var transcript: TextView
    private var recorder: AudioRecord? = null

    @Volatile private var recording = false
    @Volatile private var worker: Thread? = null
    private var committedText = ""

    private val sampleRate = 16000
    private val requestMic = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton = findViewById(R.id.startButton)
        clearButton = findViewById(R.id.clearButton)
        transcript = findViewById(R.id.transcript)

        clearButton.setOnClickListener {
            committedText = ""
            transcript.text = ""
        }

        startButton.isEnabled = false
        transcript.text = "Türkçe konuşma modeli hazırlanıyor…"

        thread {
            try {
                initRecognizer()
                runOnUiThread {
                    transcript.text = "Hazır. Mikrofonu başlatabilirsin."
                    startButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    transcript.text = "Model açılamadı:\n${e.message}"
                }
            }
        }

        startButton.setOnClickListener { toggleRecording() }
    }

    private fun initRecognizer() {
        val dir = "turkish-stt"
        val transducer = OnlineTransducerModelConfig(
            encoder = "$dir/encoder.int8.onnx",
            decoder = "$dir/decoder.int8.onnx",
            joiner = "$dir/joiner.int8.onnx",
        )

        val model = OnlineModelConfig(
            transducer = transducer,
            tokens = "$dir/tokens.txt",
            modelingUnit = "bpe",
            bpeVocab = "$dir/bpe.model",
            provider = "cpu",
            numThreads = 2,
        )

        val config = OnlineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = sampleRate, featureDim = 80),
            modelConfig = model,
            endpointConfig = EndpointConfig(),
            enableEndpoint = true,
            decodingMethod = "modified_beam_search",
            maxActivePaths = 4,
        )

        recognizer = OnlineRecognizer(assetManager = assets, config = config)
    }

    private fun toggleRecording() {
        if (recording) {
            stopRecording()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic
            )
            return
        }

        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            transcript.text = "Mikrofon başlatılamadı (buffer: $minBuffer)."
            return
        }

        val audio = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuffer * 2
        )
        if (audio.state != AudioRecord.STATE_INITIALIZED) {
            audio.release()
            transcript.text = "Mikrofon başlatılamadı."
            return
        }

        recorder = audio
        committedText = ""
        transcript.text = ""
        audio.startRecording()
        recording = true
        startButton.text = "Dinlemeyi Durdur"

        worker = thread(name = "TurkishSTT-Audio") {
            val stream = recognizer.createStream()
            val buffer = ShortArray(1600)

            try {
                while (recording) {
                    val count = audio.read(buffer, 0, buffer.size)
                    if (count <= 0) continue

                    val samples = FloatArray(count) { buffer[it] / 32768.0f }
                    stream.acceptWaveform(samples, sampleRate = sampleRate)

                    while (recognizer.isReady(stream)) {
                        recognizer.decode(stream)
                    }

                    val current = recognizer.getResult(stream).text.trim()
                    val endpoint = recognizer.isEndpoint(stream)

                    if (endpoint) {
                        if (current.isNotBlank()) {
                            committedText = listOf(committedText, current)
                                .filter { it.isNotBlank() }.joinToString(" ")
                        }
                        recognizer.reset(stream)
                    }

                    val shown = if (!endpoint && current.isNotBlank()) {
                        listOf(committedText, current).filter { it.isNotBlank() }.joinToString(" ")
                    } else {
                        committedText
                    }

                    runOnUiThread { transcript.text = shown }
                }
            } catch (e: Exception) {
                runOnUiThread { transcript.append("\n\nSes işleme hatası: ${e.message}") }
            } finally {
                try { stream.release() } catch (_: Exception) {}
                try { audio.stop() } catch (_: Exception) {}
                audio.release()
                if (recorder === audio) recorder = null
                runOnUiThread {
                    recording = false
                    startButton.text = "Dinlemeyi Başlat"
                }
            }
        }
    }

    private fun stopRecording() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
        startButton.text = "Dinlemeyi Başlat"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestMic &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            toggleRecording()
        } else if (requestCode == requestMic) {
            transcript.text = "Mikrofon izni verilmedi."
        }
    }

    override fun onDestroy() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        super.onDestroy()
    }
}
